#!/bin/bash

docker build -f 7.3.1.dockerfile -t runserve/angular:7.3.1 .
docker build -f 7.3.2.dockerfile -t runserve/angular:7.3.2 .
docker build -f 7.3.3.dockerfile -t runserve/angular:7.3.3 .
docker build -f 7.3.4.dockerfile -t runserve/angular:7.3.4 .
docker build -f 7.3.5.dockerfile -t runserve/angular:7.3.5 .
docker build -f 7.3.6.dockerfile -t runserve/angular:7.3.6 .
docker build -f 7.3.6.dockerfile -t runserve/angular:latest .
