#!/bin/bash
docker push runserve/angular:7.3.1
docker push runserve/angular:7.3.2
docker push runserve/angular:7.3.3
docker push runserve/angular:latest
