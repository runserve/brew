#!/bin/bash
docker push runserve/angular:7.3.1
docker push runserve/angular:7.3.2
docker push runserve/angular:7.3.3
docker push runserve/angular:7.3.4
docker push runserve/angular:7.3.5
docker push runserve/angular:7.3.6
docker push runserve/angular:latest
