#!/bin/bash
docker push runserve/typescript:3.2.4
docker push runserve/typescript:latest

